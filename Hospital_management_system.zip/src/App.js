import {
  BrowserRouter as Router,
  Routes,
  Route
} from "react-router-dom";
import Dashboard from "./components/home/Dashboard";
import CreatePatient from "./screen/patient/CreatePatient";
import PatientList from "./screen/patient/PatientList";
import PatientTreatment from "./screen/patient/PatientTreatment";


function App() {
  return (

    <Router>
      <div className="d-flex">
        <Dashboard />
        <Routes>
          <Route path="/" exact element={<PatientList />}></Route> 
          <Route path="/create_patient" exact element={<CreatePatient />}></Route> 
          <Route path="/patient_treatment" exact element={<PatientTreatment />}></Route> 
          <Route path="/patient_list"  element={<PatientList />}></Route> 
        </Routes>
        {/* <Footer/> */}
      </div>
    </Router>
  )
}

export default App;
