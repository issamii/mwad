import { Button, FormControl, Grid, InputLabel, MenuItem, Paper, Select, TextareaAutosize, TextField, Typography } from '@mui/material'
import React, { useState } from 'react'
import MainWrapper from '../../components/mainWrapper/MainWrapper'
import SendIcon from '@mui/icons-material/Send';
import axios from 'axios'
import { useNavigate } from 'react-router-dom';

const CreatePatient = () => {
    let navigate = useNavigate();
    const initialFormValue = {
        "f_name": "",
        "m_name": "",
        "l_name": "",
        "contact_no": "",
        "age": "",
        "gender": "",
        "address": "",
        "prescriptions": ""
    }
    const [formData, setFormData] = useState(initialFormValue)
    const handleSubmit = (e) => {
        e.preventDefault()
        axios.post('http://192.168.11.6/LHM_backend/api/create_patient.php', formData)
            .then(function (response) {
                if (response.data.insert) {
                    setFormData(initialFormValue)
                }
            })
    }
    const showList = () => {
        navigate("/patient_list ");
    }
    return (
        <MainWrapper>
            <Grid container >
                <form onSubmit={handleSubmit}>
                    <Grid item xs={12} sx={{ m: 2 }}>
                        <div className="d-flex justify-content-between">
                            <Typography variant="h6" component="div">
                                Create Patient
                            </Typography>
                            <Button variant="contained" onClick={showList}>List</Button>
                        </div>
                    </Grid>

                    <Grid item xs={12}>
                        <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column' }}>
                            <Grid container spacing={3}>
                                <Grid item xs={4}>
                                    <TextField
                                        id="outlined-basic"
                                        label="First Name"
                                        variant="outlined"
                                        fullWidth
                                        value={formData.f_name}
                                        onChange={(e) => setFormData({ ...formData, f_name: e.target.value })}
                                        required
                                    />
                                </Grid>
                                <Grid item xs={4}>
                                    <TextField
                                        id="outlined-basic"
                                        label="Midle Name"
                                        variant="outlined"
                                        fullWidth
                                        value={formData.m_name}
                                        onChange={(e) => setFormData({ ...formData, m_name: e.target.value })}
                                        
                                    />
                                </Grid>
                                <Grid item xs={4}>
                                    <TextField
                                        id="outlined-basic"
                                        label="Last Name"
                                        variant="outlined"
                                        fullWidth
                                        value={formData.l_name}
                                        onChange={(e) => setFormData({ ...formData, l_name: e.target.value })}
                                        
                                    />
                                </Grid>
                                <Grid item xs={3}>
                                    <TextField
                                        id="outlined-basic"
                                        label="Contact No"
                                        variant="outlined"
                                        fullWidth
                                        value={formData.contact_no}
                                        onChange={(e) => setFormData({ ...formData, contact_no: e.target.value })}
                                        required
                                    />
                                </Grid>
                                <Grid item xs={3}>
                                    <TextField
                                        id="outlined-basic"
                                        label="Age"
                                        variant="outlined"
                                        fullWidth
                                        value={formData.age}
                                        onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                                        required
                                    />
                                </Grid>
                                <Grid item xs={3}>
                                    <FormControl fullWidth>
                                        <InputLabel id="demo-simple-select-label">Gender</InputLabel>
                                        <Select
                                            labelId="demo-simple-select-label"
                                            id="demo-simple-select"
                                            label="Gender"
                                            value={formData.gender}
                                            onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                                            required
                                        >
                                            <MenuItem value={1}>Male</MenuItem>
                                            <MenuItem value={2}>Female</MenuItem>
                                            <MenuItem value={3}>Other</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Grid>
                                <Grid item xs={12}>
                                    <TextField
                                        id="outlined-basic"
                                        label="Address"
                                        variant="outlined"
                                        fullWidth
                                        value={formData.address}
                                        onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                                        required
                                    />
                                </Grid>

                            </Grid>
                        </Paper>
                    </Grid>
                    <Grid item xs={12} sx={{ m: 2 }}>
                        <Typography variant="h6" component="div">
                            Treatment
                        </Typography>
                    </Grid>
                    <Grid item xs={12}>
                        <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column' }}>
                            <Grid container spacing={3}>
                                <Grid item xs={12}>
                                    <TextField
                                        id="outlined-basic"
                                        label="Prescriptions"
                                        variant="outlined"
                                        fullWidth
                                        value={formData.prescriptions}
                                        onChange={(e) => setFormData({ ...formData, prescriptions: e.target.value })}
                                        required
                                    />
                                </Grid>
                                <Grid item xs={12} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                    <Button variant="outlined" type='sumit' endIcon={<SendIcon />}>
                                        Save
                                    </Button>
                                </Grid>
                            </Grid>
                        </Paper>
                    </Grid>
                </form>
            </Grid>
        </MainWrapper>
    )
}

export default CreatePatient
