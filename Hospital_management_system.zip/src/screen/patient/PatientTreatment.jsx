import React from 'react'
import MainWrapper from '../../components/mainWrapper/MainWrapper'

const PatientTreatment = () => {
    return (
        <MainWrapper>
            <h1>PatientTreatment</h1>
        </MainWrapper>
    )
}

export default PatientTreatment
