import { Button, getTypographyUtilityClass, Grid, Paper, Typography } from '@mui/material'
import { AgGridReact } from 'ag-grid-react/lib/agGridReact'
import { AgGridColumn } from 'ag-grid-react/lib/shared/agGridColumn'
import React, { useState } from 'react'
import MainWrapper from '../../components/mainWrapper/MainWrapper'

const PatientList = () => {
    const [rowData, setRowData] = useState(null);
    const onGridReady = (params) => {
        const updateData = (data) => params.api.setRowData(data);
        fetch('http://192.168.11.6/LHM_backend/api/fetch_patient.php')
            .then((resp) => resp.json())
            .then((data) => updateData(data));
    };
    return (
        <MainWrapper>
            <Grid container >
                <Grid item xs={12} sx={{ m: 2 }}>
                    <div className="d-flex justify-content-between">
                        <Typography variant="h6" component="div">
                            All Patients
                        </Typography>
                    </div>
                </Grid>
                <Grid item xs={12}>
                    <Paper sx={{ p: 2 }} elevation={3} style={{ height: 'calc(100vh - 197px)' }}>
                        <div className="ag-theme-alpine" style={{
                            height: '100%',
                            width: '100%',
                        }}>
                            <AgGridReact
                                pagination={true}
                                onGridReady={onGridReady}
                                rowData={rowData}
                            >
                                <AgGridColumn resizable={true} field="id" headerName="Code" width="100" sortable={true} filter={true}></AgGridColumn>
                                <AgGridColumn resizable={true} field="full_name" headerName="Full Name" sortable={true} filter={true}></AgGridColumn>
                                <AgGridColumn resizable={true} field="contact_no" headerName="Contact No" sortable={true} filter={true}></AgGridColumn>
                                <AgGridColumn resizable={true} field="age" headerName="Age" sortable={true} filter={true}></AgGridColumn>
                                <AgGridColumn resizable={true} field="gender" headerName="Gender" sortable={true} filter={true}></AgGridColumn>
                                <AgGridColumn resizable={true} field="address" headerName="Address" sortable={true} filter={true}></AgGridColumn>
                                <AgGridColumn resizable={true} field="prescriptions" headerName="Prescriptions" sortable={true} filter={true}></AgGridColumn>
                                <AgGridColumn resizable={true} field="actions" headerName="Actions" sortable={true} filter={true} cellRendererParams={{ clicked: (field)=>{
                                    alert(`${field} was clicked`);
                                }}} ></AgGridColumn>
                            </AgGridReact>
                        </div>

                    </Paper>
                </Grid>
            </Grid>
        </MainWrapper>
    )
}

export default PatientList
