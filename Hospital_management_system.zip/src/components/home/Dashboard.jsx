import * as React from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Link from '@mui/material/Link';
import MyAppBar from '../dashboard/MyAppBar.jsx';
import MyDrawer from '../dashboard/MyDrawer.jsx';


function Copyright(props) {
    return (
        <Typography variant="body2" color="text.secondary" align="center" {...props}>
            {'Copyright © '}
            <Link color="inherit" href="https://mui.com/">
                Your Website
            </Link>{' '}
            {new Date().getFullYear()}
            {'.'}
        </Typography>
    );
}

const drawerwidth = 240;

const mdTheme = createTheme();

function DashboardContent() {
    const [open, setOpen] = React.useState(true);
    const toggleDrawer = () => {
        setOpen(!open);
    };

    return (
        <>
            <CssBaseline />
            <MyAppBar toggleDrawer={toggleDrawer} drawerwidth={drawerwidth} open={open} />
            <MyDrawer toggleDrawer={toggleDrawer} drawerwidth={drawerwidth} open={open} />

        </>
    );
}

const Dashboard = () => {
    return <DashboardContent />;
}

export default Dashboard