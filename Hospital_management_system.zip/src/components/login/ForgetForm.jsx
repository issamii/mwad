import React from 'react'

const ForgetForm = ({ handleForgetPassword }) => {
    return (
        <div id="forgetform">
            <div className="top_title">
                <h4>Reset your password</h4>
                <p className="mt-12">Enter the email address associated with your account and we'll send
                    you a link to
                    reset your password.</p>
            </div>

            <div className="form-group mt-32">
                <label className="form-label mt-12">Email Address</label>
                <input type="email" className="form-control mt-12" name="Lupa[email]" id="email_id" placeholder="Johndoe@gmail.com" required />
            </div>

            <button type="submit" className="btn btn_primary btn_primary_gradient w-100 mt-32">Continue</button>
            <div className="mt-32">
                <p className="text-center" id="backToLogin" onClick={handleForgetPassword}>Back To Sign In</p>
            </div>
        </div>
    )
}

export default ForgetForm
