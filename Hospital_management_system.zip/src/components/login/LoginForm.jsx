import React from 'react'

const LoginForm = ({handleForgetPassword,loginUser}) => {
    return (
        <div id="login_form">
        <div className="top_title">
            <h4>Sign in to your account</h4>
        </div>
        <div className="form-group">
            <label className="form-label mt-12">Email address</label>
            <input type="email" className="form-control mt-6" id="username" name="username" placeholder="Johndoe@gmail.com" aria-describedby="emailHelp" required />
            <label id="username-error" className="error" ></label>
        </div>
        <div className="mt-32">
            <div className="forget_password d-flex align-items-center justify-content-between">
                <label className="form-label mt-12">Password</label>
                <span id="forgetPassword" onClick={handleForgetPassword}>
                    Forgot your password?
                </span>
            </div>
            <div className="passwrod_field mt-6 d-flex align-items-center" id="passwrod_field">
                <input type="password" className="" placeholder="Enter Your Password" name="password" required id="password" />
                <span id="show_password" className="d-none"><i className="fas fa-eye" id="show_icon"></i></span>
            </div>
            <label id="password-error" className="error" ></label>
        </div>
        <button type="button" onClick={loginUser} id="submit_btn" className="btn btn_primary btn_primary_gradient w-100 mt-32">
            <span>Submit</span>
            <div className="spinner-border text-skyBlue float-end" id="spinner" role="status"></div>
        </button>
    </div>
    )
}

export default LoginForm
